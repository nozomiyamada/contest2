from karel.functions2 import *
start() 

####### DO NOT EDIT CODE ABOVE THIS LINE ########

def main():
    """
    Your code goes here! (do not forget indent(tab))
    """
    






####### DO NOT EDIT CODE BELOW THIS LINE ########

if __name__ == '__main__':
    execute_karel_task(main)