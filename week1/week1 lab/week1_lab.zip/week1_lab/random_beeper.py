from karel.stanfordkarel import *
from random import randint

def random_beeper():
    lim = 2
    for i in range(7):
        move()
        if lim > 0 and (randint(0,1) == 1 or (not front_is_clear())):
            put_beeper()
            lim -= 1