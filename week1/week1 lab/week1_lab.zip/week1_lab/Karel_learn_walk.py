from karel.stanfordkarel import *


def main():
    """
    Your code goes here!
    """

####### DO NOT EDIT CODE BELOW THIS LINE ########

if __name__ == '__main__':
    execute_karel_task(main)
