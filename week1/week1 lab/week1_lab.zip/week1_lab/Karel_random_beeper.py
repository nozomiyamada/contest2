from karel.stanfordkarel import *
from random_beeper import *


def main():
    random_beeper()

####### DO NOT EDIT CODE ABOVE THIS LINE ########
    """
    Your code goes here!
    """

####### DO NOT EDIT CODE BELOW THIS LINE ########

if __name__ == '__main__':
    execute_karel_task(main)
